<?php
session_destroy();
?>

<script>
    window.location.href = 'Register.php';
</script>